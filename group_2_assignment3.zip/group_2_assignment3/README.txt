README
1. Open the Zip file
2. Run the python file to take a text file containing a book's text and generate the three separate
text files, allwords.txt, uniquewords.txt, and wordfrequency.txt for further processing.

The only other thing that needs be done is define the file name and/or directory location of the
text file being processed if using one other than the one provided (Pride and Prejudice).

3. To view the word cloud, click on the wordcloud.PNG to view the word cloud 

4. To run a3_novelvisualization, open the a3_novelvisualizaton folder(which should have the a3_novelvisualizaton.pde and uniquewords.txt). Open the a3_novelvisualizaton.pde and press run. A word cloud will be generated once it is run. To create a new word cloud press the mouse pad. 

5. To run a3_wordfrequency, open the a3_wordfrequency folder(which should have the a3_wordfrequency.pde as well as the wordfrequency.txt). Open the a3_wordfrequency.pde file and press run